package com.alipay.cloudrun.superapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperappApplicationTests {

	@Test
	void contextLoads() {
	}

}
